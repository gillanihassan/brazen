import Mystery from "./myster/page/Mystery";

function App() {
  return (
    <>
      <Mystery />
    </>
  );
}

export default App;
